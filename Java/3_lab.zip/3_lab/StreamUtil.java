import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

public class StreamUtil {
    public static void output(Item item, OutputStream out) throws IOException {
        item.output(out);
    }

    public static Item input(InputStream in) throws IOException {
        DataInputStream dis = new DataInputStream(in);
        int id = dis.readInt();
        String name = dis.readUTF();
        int length = dis.readInt();
        int[] values = new int[length];
        for (int i = 0; i < length; i++) values[i] = dis.readInt();

        // Возвращаем новый объект Service (или Product по аналогии)
        return new Service(values, name, id);
    }

    public static void write(Item item, Writer out) throws IOException {
        item.write(out);
        // Используем flush для гарантийной записи
        out.flush();
    }

    public static Item read(Reader in) throws IOException {
        BufferedReader br = new BufferedReader(in);
        String line = br.readLine();
        if (line == null) {
            return null; // возвращаем null при достижении конца файла
        }
    
        String[] parts = line.split(" ");
        
        if (parts.length < 3) {
            throw new IOException("Invalid file format.");
        }
    
        int id = Integer.parseInt(parts[0]);
        String name = parts[1];
        String[] valuesStr = parts[2].replace("[", "").replace("]", "").split(",");
        int[] values = Arrays.stream(valuesStr).mapToInt(Integer::parseInt).toArray();
    
        return new Product(values, name, id); // Здесь используем Product по умолчанию
    }
    

    public static void serialize(Item item, OutputStream out) throws IOException {
        ObjectOutputStream oos = new ObjectOutputStream(out);
        oos.writeObject(item);
        oos.flush();
    }

    public static Item deserialize(InputStream in) throws IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(in);
        return (Item) ois.readObject();
    }

    public static void writeFormat(Item item, Writer out) throws IOException {
        if (item instanceof Product) {
            Product product = (Product) item;
            out.write(String.format("%d %s %s%n", product.getId(), product.getName(), Arrays.toString(product.getPrices())));
        } else if (item instanceof Service) {
            Service service = (Service) item;
            out.write(String.format("%d %s %s%n", service.getId(), service.getName(), Arrays.toString(service.getCosts())));
        }
        out.flush(); // Не забудьте записать данные
    }

    public static Item readFormat(Scanner in) {
        int id = in.nextInt();
        String name = in.next();
        String[] valuesStr = in.next().replace("[", "").replace("]", "").split(",");
        
        int[] values = Arrays.stream(valuesStr).mapToInt(Integer::parseInt).toArray();

        return new Product(values, name, id);
    }
}
